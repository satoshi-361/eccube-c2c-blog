<?php
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/lib/Doctrine/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder7a718 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerd727f = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties079b9 = [
        
    ];

    public function getConnection()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getConnection', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getMetadataFactory', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getExpressionBuilder', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'beginTransaction', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getCache', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getCache();
    }

    public function transactional($func)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'transactional', array('func' => $func), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->transactional($func);
    }

    public function commit()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'commit', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->commit();
    }

    public function rollback()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'rollback', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getClassMetadata', array('className' => $className), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'createQuery', array('dql' => $dql), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'createNamedQuery', array('name' => $name), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'createQueryBuilder', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'flush', array('entity' => $entity), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'clear', array('entityName' => $entityName), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->clear($entityName);
    }

    public function close()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'close', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->close();
    }

    public function persist($entity)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'persist', array('entity' => $entity), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'remove', array('entity' => $entity), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'refresh', array('entity' => $entity), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'detach', array('entity' => $entity), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'merge', array('entity' => $entity), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getRepository', array('entityName' => $entityName), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'contains', array('entity' => $entity), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getEventManager', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getConfiguration', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'isOpen', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getUnitOfWork', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getProxyFactory', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'initializeObject', array('obj' => $obj), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getFilters', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'isFiltersStateClean', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'hasFilters', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerd727f = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder7a718) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder7a718 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder7a718->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, '__get', ['name' => $name], $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        if (isset(self::$publicProperties079b9[$name])) {
            return $this->valueHolder7a718->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder7a718;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder7a718;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder7a718;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder7a718;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, '__isset', array('name' => $name), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder7a718;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder7a718;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, '__unset', array('name' => $name), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder7a718;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder7a718;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, '__clone', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        $this->valueHolder7a718 = clone $this->valueHolder7a718;
    }

    public function __sleep()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, '__sleep', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return array('valueHolder7a718');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerd727f = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerd727f;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'initializeProxy', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder7a718;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder7a718;
    }


}
