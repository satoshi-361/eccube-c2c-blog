<?php
include_once \dirname(__DIR__, 4).'/src/Eccube/Service/CartService.php';

class CartService_9dde17f extends \Eccube\Service\CartService implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Eccube\Service\CartService|null wrapped object, if the proxy is initialized
     */
    private $valueHolder7a718 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerd727f = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties079b9 = [
        
    ];

    public function getCarts($empty_delete = false)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getCarts', array('empty_delete' => $empty_delete), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getCarts($empty_delete);
    }

    public function getPersistedCarts()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getPersistedCarts', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getPersistedCarts();
    }

    public function getSessionCarts()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getSessionCarts', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getSessionCarts();
    }

    public function mergeFromPersistedCart()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'mergeFromPersistedCart', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->mergeFromPersistedCart();
    }

    public function getCart()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getCart', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getCart();
    }

    public function addProduct($ProductClass, $quantity = 1)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'addProduct', array('ProductClass' => $ProductClass, 'quantity' => $quantity), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->addProduct($ProductClass, $quantity);
    }

    public function removeProduct($ProductClass)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'removeProduct', array('ProductClass' => $ProductClass), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->removeProduct($ProductClass);
    }

    public function save()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'save', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->save();
    }

    public function setPreOrderId($pre_order_id)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'setPreOrderId', array('pre_order_id' => $pre_order_id), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->setPreOrderId($pre_order_id);
    }

    public function getPreOrderId()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getPreOrderId', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getPreOrderId();
    }

    public function clear()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'clear', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->clear();
    }

    public function setCartItemComparator($cartItemComparator)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'setCartItemComparator', array('cartItemComparator' => $cartItemComparator), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->setCartItemComparator($cartItemComparator);
    }

    public function setPrimary($cartKey)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'setPrimary', array('cartKey' => $cartKey), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->setPrimary($cartKey);
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        unset($instance->carts, $instance->session, $instance->entityManager, $instance->cart, $instance->productClassRepository, $instance->cartRepository, $instance->cartItemComparator, $instance->cartItemAllocator, $instance->orderRepository, $instance->tokenStorage, $instance->authorizationChecker);

        $instance->initializerd727f = $initializer;

        return $instance;
    }

    public function __construct(\Symfony\Component\HttpFoundation\Session\SessionInterface $session, \Doctrine\ORM\EntityManagerInterface $entityManager, \Eccube\Repository\ProductClassRepository $productClassRepository, \Eccube\Repository\CartRepository $cartRepository, \Eccube\Service\Cart\CartItemComparator $cartItemComparator, \Eccube\Service\Cart\CartItemAllocator $cartItemAllocator, \Eccube\Repository\OrderRepository $orderRepository, \Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface $tokenStorage, \Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface $authorizationChecker)
    {
        static $reflection;

        if (! $this->valueHolder7a718) {
            $reflection = $reflection ?? new \ReflectionClass('Eccube\\Service\\CartService');
            $this->valueHolder7a718 = $reflection->newInstanceWithoutConstructor();
        unset($this->carts, $this->session, $this->entityManager, $this->cart, $this->productClassRepository, $this->cartRepository, $this->cartItemComparator, $this->cartItemAllocator, $this->orderRepository, $this->tokenStorage, $this->authorizationChecker);

        }

        $this->valueHolder7a718->__construct($session, $entityManager, $productClassRepository, $cartRepository, $cartItemComparator, $cartItemAllocator, $orderRepository, $tokenStorage, $authorizationChecker);
    }

    public function & __get($name)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, '__get', ['name' => $name], $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        if (isset(self::$publicProperties079b9[$name])) {
            return $this->valueHolder7a718->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Eccube\\Service\\CartService');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder7a718;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder7a718;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        $realInstanceReflection = new \ReflectionClass('Eccube\\Service\\CartService');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder7a718;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder7a718;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, '__isset', array('name' => $name), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        $realInstanceReflection = new \ReflectionClass('Eccube\\Service\\CartService');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder7a718;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder7a718;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, '__unset', array('name' => $name), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        $realInstanceReflection = new \ReflectionClass('Eccube\\Service\\CartService');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder7a718;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder7a718;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, '__clone', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        $this->valueHolder7a718 = clone $this->valueHolder7a718;
    }

    public function __sleep()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, '__sleep', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return array('valueHolder7a718');
    }

    public function __wakeup()
    {
        unset($this->carts, $this->session, $this->entityManager, $this->cart, $this->productClassRepository, $this->cartRepository, $this->cartItemComparator, $this->cartItemAllocator, $this->orderRepository, $this->tokenStorage, $this->authorizationChecker);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerd727f = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerd727f;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'initializeProxy', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder7a718;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder7a718;
    }


}
