<?php
include_once \dirname(__DIR__, 4).'/src/Eccube/Service/Composer/ComposerServiceInterface.php';
include_once \dirname(__DIR__, 4).'/src/Eccube/Service/Composer/ComposerApiService.php';

class ComposerApiService_c77e330 extends \Eccube\Service\Composer\ComposerApiService implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Eccube\Service\Composer\ComposerApiService|null wrapped object, if the proxy is initialized
     */
    private $valueHolder7a718 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerd727f = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties079b9 = [
        
    ];

    public function execInfo($pluginName, $version)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'execInfo', array('pluginName' => $pluginName, 'version' => $version), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->execInfo($pluginName, $version);
    }

    public function execRequire($packageName, $output = null)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'execRequire', array('packageName' => $packageName, 'output' => $output), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->execRequire($packageName, $output);
    }

    public function execRemove($packageName, $output = null)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'execRemove', array('packageName' => $packageName, 'output' => $output), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->execRemove($packageName, $output);
    }

    public function execUpdate($dryRun, $output = null)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'execUpdate', array('dryRun' => $dryRun, 'output' => $output), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->execUpdate($dryRun, $output);
    }

    public function execInstall($dryRun, $output = null)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'execInstall', array('dryRun' => $dryRun, 'output' => $output), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->execInstall($dryRun, $output);
    }

    public function foreachRequires($packageName, $version, $callback, $typeFilter = null, $level = 0)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'foreachRequires', array('packageName' => $packageName, 'version' => $version, 'callback' => $callback, 'typeFilter' => $typeFilter, 'level' => $level), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->foreachRequires($packageName, $version, $callback, $typeFilter, $level);
    }

    public function execConfig($key, $value = null)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'execConfig', array('key' => $key, 'value' => $value), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->execConfig($key, $value);
    }

    public function getConfig()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'getConfig', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->getConfig();
    }

    public function setWorkingDir($workingDir)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'setWorkingDir', array('workingDir' => $workingDir), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->setWorkingDir($workingDir);
    }

    public function runCommand($commands, $output = null, $init = true)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'runCommand', array('commands' => $commands, 'output' => $output, 'init' => $init), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->runCommand($commands, $output, $init);
    }

    public function configureRepository(\Eccube\Entity\BaseInfo $BaseInfo)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'configureRepository', array('BaseInfo' => $BaseInfo), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return $this->valueHolder7a718->configureRepository($BaseInfo);
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        unset($instance->eccubeConfig);

        \Closure::bind(function (\Eccube\Service\Composer\ComposerApiService $instance) {
            unset($instance->consoleApplication, $instance->workingDir, $instance->baseInfoRepository, $instance->schemaService, $instance->pluginContext);
        }, $instance, 'Eccube\\Service\\Composer\\ComposerApiService')->__invoke($instance);

        $instance->initializerd727f = $initializer;

        return $instance;
    }

    public function __construct(\Eccube\Common\EccubeConfig $eccubeConfig, \Eccube\Repository\BaseInfoRepository $baseInfoRepository, \Eccube\Service\SchemaService $schemaService, \Eccube\Service\PluginContext $pluginContext)
    {
        static $reflection;

        if (! $this->valueHolder7a718) {
            $reflection = $reflection ?? new \ReflectionClass('Eccube\\Service\\Composer\\ComposerApiService');
            $this->valueHolder7a718 = $reflection->newInstanceWithoutConstructor();
        unset($this->eccubeConfig);

        \Closure::bind(function (\Eccube\Service\Composer\ComposerApiService $instance) {
            unset($instance->consoleApplication, $instance->workingDir, $instance->baseInfoRepository, $instance->schemaService, $instance->pluginContext);
        }, $this, 'Eccube\\Service\\Composer\\ComposerApiService')->__invoke($this);

        }

        $this->valueHolder7a718->__construct($eccubeConfig, $baseInfoRepository, $schemaService, $pluginContext);
    }

    public function & __get($name)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, '__get', ['name' => $name], $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        if (isset(self::$publicProperties079b9[$name])) {
            return $this->valueHolder7a718->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Eccube\\Service\\Composer\\ComposerApiService');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder7a718;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder7a718;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        $realInstanceReflection = new \ReflectionClass('Eccube\\Service\\Composer\\ComposerApiService');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder7a718;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder7a718;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, '__isset', array('name' => $name), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        $realInstanceReflection = new \ReflectionClass('Eccube\\Service\\Composer\\ComposerApiService');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder7a718;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder7a718;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, '__unset', array('name' => $name), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        $realInstanceReflection = new \ReflectionClass('Eccube\\Service\\Composer\\ComposerApiService');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder7a718;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder7a718;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, '__clone', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        $this->valueHolder7a718 = clone $this->valueHolder7a718;
    }

    public function __sleep()
    {
        $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, '__sleep', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;

        return array('valueHolder7a718');
    }

    public function __wakeup()
    {
        unset($this->eccubeConfig);

        \Closure::bind(function (\Eccube\Service\Composer\ComposerApiService $instance) {
            unset($instance->consoleApplication, $instance->workingDir, $instance->baseInfoRepository, $instance->schemaService, $instance->pluginContext);
        }, $this, 'Eccube\\Service\\Composer\\ComposerApiService')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerd727f = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerd727f;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerd727f && ($this->initializerd727f->__invoke($valueHolder7a718, $this, 'initializeProxy', array(), $this->initializerd727f) || 1) && $this->valueHolder7a718 = $valueHolder7a718;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder7a718;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder7a718;
    }


}
